import 'package:flutter/material.dart';
import '../presentation/driver_dashboard_screen/driver_dashboard_screen.dart';
import '../presentation/passenger_home_screen/passenger_home_screen.dart';
import '../presentation/splash_screen/splash_screen.dart';
import '../presentation/authentication_screen/authentication_screen.dart';
import '../presentation/role_selection_screen/role_selection_screen.dart';
import '../presentation/onboarding_flow/onboarding_flow.dart';

class AppRoutes {
  // TODO: Add your routes here
  static const String initial = '/';
  static const String driverDashboard = '/driver-dashboard-screen';
  static const String passengerHome = '/passenger-home-screen';
  static const String splash = '/splash-screen';
  static const String authentication = '/authentication-screen';
  static const String roleSelection = '/role-selection-screen';
  static const String onboardingFlow = '/onboarding-flow';

  static Map<String, WidgetBuilder> routes = {
    initial: (context) => const SplashScreen(),
    driverDashboard: (context) => const DriverDashboardScreen(),
    passengerHome: (context) => const PassengerHomeScreen(),
    splash: (context) => const SplashScreen(),
    authentication: (context) => const AuthenticationScreen(),
    roleSelection: (context) => const RoleSelectionScreen(),
    onboardingFlow: (context) => const OnboardingFlow(),
    // TODO: Add your other routes here
  };
}
