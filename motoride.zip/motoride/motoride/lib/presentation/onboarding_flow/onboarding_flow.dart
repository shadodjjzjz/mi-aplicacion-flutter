import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import '../../theme/app_theme.dart';
import './widgets/navigation_buttons_widget.dart';
import './widgets/onboarding_page_widget.dart';
import './widgets/page_indicator_widget.dart';

class OnboardingFlow extends StatefulWidget {
  const OnboardingFlow({Key? key}) : super(key: key);

  @override
  State<OnboardingFlow> createState() => _OnboardingFlowState();
}

class _OnboardingFlowState extends State<OnboardingFlow>
    with TickerProviderStateMixin {
  late PageController _pageController;
  late AnimationController _fadeController;
  late Animation<double> _fadeAnimation;
  Timer? _autoAdvanceTimer;
  int _currentPage = 0;
  bool _userInteracted = false;

  final List<Map<String, dynamic>> _onboardingData = [
    {
      "imageUrl":
          "https://images.pexels.com/photos/2116475/pexels-photo-2116475.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
      "title": "Viaja Rápido y Seguro",
      "description":
          "Conecta con conductores de motocicleta verificados para llegar a tu destino de manera rápida y económica. Evita el tráfico y ahorra tiempo en cada viaje."
    },
    {
      "imageUrl":
          "https://images.pexels.com/photos/1119796/pexels-photo-1119796.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
      "title": "Gana Dinero Conduciendo",
      "description":
          "¿Tienes una motocicleta? Conviértete en conductor y genera ingresos adicionales transportando pasajeros de forma segura. Horarios flexibles, ganancias reales."
    },
    {
      "imageUrl":
          "https://images.pexels.com/photos/1119796/pexels-photo-1119796.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
      "title": "Tu Seguridad es Nuestra Prioridad",
      "description":
          "Sistema de seguimiento GPS en tiempo real, conductores verificados, y soporte 24/7. Viaja con confianza sabiendo que estás protegido en cada trayecto."
    }
  ];

  @override
  void initState() {
    super.initState();
    _pageController = PageController();
    _fadeController = AnimationController(
      duration: const Duration(milliseconds: 500),
      vsync: this,
    );
    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _fadeController, curve: Curves.easeInOut),
    );

    _fadeController.forward();
    _startAutoAdvanceTimer();
  }

  @override
  void dispose() {
    _pageController.dispose();
    _fadeController.dispose();
    _autoAdvanceTimer?.cancel();
    super.dispose();
  }

  void _startAutoAdvanceTimer() {
    _autoAdvanceTimer?.cancel();
    _autoAdvanceTimer = Timer.periodic(const Duration(seconds: 8), (timer) {
      if (!_userInteracted && mounted) {
        _nextPage();
      }
    });
  }

  void _pauseAutoAdvance() {
    setState(() {
      _userInteracted = true;
    });
    _autoAdvanceTimer?.cancel();
  }

  void _nextPage() {
    if (_currentPage < _onboardingData.length - 1) {
      HapticFeedback.lightImpact();
      _pageController.nextPage(
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeInOut,
      );
    }
  }

  void _skipOnboarding() {
    HapticFeedback.mediumImpact();
    _navigateToRoleSelection();
  }

  void _startRiding() {
    HapticFeedback.mediumImpact();
    Navigator.pushReplacementNamed(context, '/passenger-home-screen');
  }

  void _startDriving() {
    HapticFeedback.mediumImpact();
    Navigator.pushReplacementNamed(context, '/driver-dashboard-screen');
  }

  void _navigateToRoleSelection() {
    Navigator.pushReplacementNamed(context, '/role-selection-screen');
  }

  Future<bool> _onWillPop() async {
    if (_currentPage > 0) {
      HapticFeedback.lightImpact();
      _pageController.previousPage(
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeInOut,
      );
      return false;
    } else {
      return await _showExitConfirmation();
    }
  }

  Future<bool> _showExitConfirmation() async {
    return await showDialog<bool>(
          context: context,
          builder: (context) => AlertDialog(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16),
            ),
            title: Text(
              '¿Salir de MotoRide?',
              style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.w600,
              ),
            ),
            content: Text(
              '¿Estás seguro de que quieres salir de la aplicación?',
              style: AppTheme.lightTheme.textTheme.bodyMedium,
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.of(context).pop(false),
                child: Text(
                  'Cancelar',
                  style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                    color: AppTheme.lightTheme.colorScheme.onSurface
                        .withValues(alpha: 0.7),
                  ),
                ),
              ),
              ElevatedButton(
                onPressed: () => Navigator.of(context).pop(true),
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppTheme.lightTheme.colorScheme.error,
                  foregroundColor: AppTheme.lightTheme.colorScheme.onError,
                ),
                child: const Text('Salir'),
              ),
            ],
          ),
        ) ??
        false;
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: _onWillPop,
      child: Scaffold(
        backgroundColor: AppTheme.lightTheme.scaffoldBackgroundColor,
        body: FadeTransition(
          opacity: _fadeAnimation,
          child: Column(
            children: [
              // Skip button in top-right corner
              SafeArea(
                child: Align(
                  alignment: Alignment.topRight,
                  child: Padding(
                    padding: EdgeInsets.only(top: 2.h, right: 4.w),
                    child: _currentPage < _onboardingData.length - 1
                        ? TextButton(
                            onPressed: _skipOnboarding,
                            child: Text(
                              'Saltar',
                              style: AppTheme.lightTheme.textTheme.bodyLarge
                                  ?.copyWith(
                                color: AppTheme.lightTheme.colorScheme.onSurface
                                    .withValues(alpha: 0.7),
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          )
                        : const SizedBox.shrink(),
                  ),
                ),
              ),
              // PageView
              Expanded(
                child: PageView.builder(
                  controller: _pageController,
                  onPageChanged: (index) {
                    setState(() {
                      _currentPage = index;
                    });
                    _pauseAutoAdvance();
                    HapticFeedback.selectionClick();
                  },
                  itemCount: _onboardingData.length,
                  itemBuilder: (context, index) {
                    final data = _onboardingData[index];
                    return OnboardingPageWidget(
                      imageUrl: data["imageUrl"] as String,
                      title: data["title"] as String,
                      description: data["description"] as String,
                      isLastPage: index == _onboardingData.length - 1,
                    );
                  },
                ),
              ),
              // Page indicator
              Padding(
                padding: EdgeInsets.symmetric(vertical: 2.h),
                child: PageIndicatorWidget(
                  currentPage: _currentPage,
                  totalPages: _onboardingData.length,
                ),
              ),
              // Navigation buttons
              NavigationButtonsWidget(
                currentPage: _currentPage,
                totalPages: _onboardingData.length,
                onNext: _nextPage,
                onSkip: _skipOnboarding,
                onStartRiding: _startRiding,
                onStartDriving: _startDriving,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
