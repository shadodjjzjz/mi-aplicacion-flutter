import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/continue_button_widget.dart';
import './widgets/role_card_widget.dart';
import './widgets/role_toggle_widget.dart';

class RoleSelectionScreen extends StatefulWidget {
  const RoleSelectionScreen({Key? key}) : super(key: key);

  @override
  State<RoleSelectionScreen> createState() => _RoleSelectionScreenState();
}

class _RoleSelectionScreenState extends State<RoleSelectionScreen>
    with TickerProviderStateMixin {
  bool _isDriverSelected = false;
  late AnimationController _fadeController;
  late AnimationController _slideController;
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;

  // Mock data for role information
  final Map<String, dynamic> _passengerData = {
    "title": "Pasajero",
    "subtitle": "Viaja cómodo y seguro",
    "description":
        "Solicita viajes rápidos y confiables con conductores verificados en toda la ciudad.",
    "benefits": [
      "Tarifas transparentes y justas",
      "Conductores verificados y calificados",
      "Seguimiento en tiempo real del viaje",
      "Múltiples opciones de pago",
      "Soporte 24/7 disponible"
    ],
    "imageUrl":
        "https://images.pexels.com/photos/1149831/pexels-photo-1149831.jpeg?auto=compress&cs=tinysrgb&w=800",
    "estimatedWaitTime": "2-5 min",
    "averageRating": "4.8"
  };

  final Map<String, dynamic> _driverData = {
    "title": "Conductor",
    "subtitle": "Gana dinero conduciendo",
    "description":
        "Conviértete en socio conductor y genera ingresos flexibles con tu motocicleta.",
    "benefits": [
      "Ganancias de hasta \$800 por semana",
      "Horarios 100% flexibles",
      "Pagos semanales garantizados",
      "Bonos por productividad",
      "Seguro incluido durante viajes"
    ],
    "imageUrl":
        "https://images.pexels.com/photos/2116475/pexels-photo-2116475.jpeg?auto=compress&cs=tinysrgb&w=800",
    "potentialEarnings": "\$15-25/hora",
    "activeDrivers": "2,500+"
  };

  @override
  void initState() {
    super.initState();
    _initializeAnimations();
    _startEntryAnimation();
  }

  void _initializeAnimations() {
    _fadeController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );

    _slideController = AnimationController(
      duration: const Duration(milliseconds: 600),
      vsync: this,
    );

    _fadeAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _fadeController,
      curve: Curves.easeOut,
    ));

    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, 0.3),
      end: Offset.zero,
    ).animate(CurvedAnimation(
      parent: _slideController,
      curve: Curves.easeOutCubic,
    ));
  }

  void _startEntryAnimation() {
    Future.delayed(const Duration(milliseconds: 100), () {
      _fadeController.forward();
      _slideController.forward();
    });
  }

  @override
  void dispose() {
    _fadeController.dispose();
    _slideController.dispose();
    super.dispose();
  }

  void _handleRoleToggle(bool isDriver) {
    if (_isDriverSelected != isDriver) {
      HapticFeedback.selectionClick();
      setState(() {
        _isDriverSelected = isDriver;
      });
    }
  }

  void _handleContinue() {
    HapticFeedback.mediumImpact();

    if (_isDriverSelected) {
      // Navigate to driver dashboard
      Navigator.pushNamed(context, '/driver-dashboard-screen');
    } else {
      // Navigate to passenger home
      Navigator.pushNamed(context, '/passenger-home-screen');
    }
  }

  void _handleBackNavigation() {
    HapticFeedback.lightImpact();
    Navigator.pushNamed(context, '/authentication-screen');
  }

  void _handleSettingsNavigation() {
    HapticFeedback.lightImpact();
    // Navigate to settings or show settings modal
    _showSettingsModal();
  }

  void _showSettingsModal() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
        decoration: BoxDecoration(
          color: AppTheme.lightTheme.colorScheme.surface,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
        ),
        padding: EdgeInsets.all(4.w),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 12.w,
              height: 0.5.h,
              decoration: BoxDecoration(
                color: AppTheme.lightTheme.dividerColor,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            SizedBox(height: 3.h),
            Text(
              'Configuración',
              style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.w600,
              ),
            ),
            SizedBox(height: 3.h),
            ListTile(
              leading: CustomIconWidget(
                iconName: 'person',
                color: AppTheme.lightTheme.colorScheme.primary,
                size: 24,
              ),
              title: const Text('Perfil de Usuario'),
              trailing: CustomIconWidget(
                iconName: 'arrow_forward_ios',
                color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                size: 16,
              ),
              onTap: () => Navigator.pop(context),
            ),
            ListTile(
              leading: CustomIconWidget(
                iconName: 'notifications',
                color: AppTheme.lightTheme.colorScheme.primary,
                size: 24,
              ),
              title: const Text('Notificaciones'),
              trailing: CustomIconWidget(
                iconName: 'arrow_forward_ios',
                color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                size: 16,
              ),
              onTap: () => Navigator.pop(context),
            ),
            ListTile(
              leading: CustomIconWidget(
                iconName: 'help',
                color: AppTheme.lightTheme.colorScheme.primary,
                size: 24,
              ),
              title: const Text('Ayuda y Soporte'),
              trailing: CustomIconWidget(
                iconName: 'arrow_forward_ios',
                color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                size: 16,
              ),
              onTap: () => Navigator.pop(context),
            ),
            SizedBox(height: 2.h),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.lightTheme.scaffoldBackgroundColor,
      body: SafeArea(
        child: FadeTransition(
          opacity: _fadeAnimation,
          child: SlideTransition(
            position: _slideAnimation,
            child: Column(
              children: [
                _buildAppBar(),
                Expanded(
                  child: SingleChildScrollView(
                    physics: const BouncingScrollPhysics(),
                    child: Column(
                      children: [
                        SizedBox(height: 2.h),
                        _buildHeader(),
                        SizedBox(height: 3.h),
                        _buildRoleCards(),
                        SizedBox(height: 3.h),
                        RoleToggleWidget(
                          isDriverSelected: _isDriverSelected,
                          onToggle: _handleRoleToggle,
                        ),
                        SizedBox(height: 4.h),
                        _buildAdditionalInfo(),
                        SizedBox(height: 3.h),
                      ],
                    ),
                  ),
                ),
                ContinueButtonWidget(
                  isDriverSelected: _isDriverSelected,
                  onPressed: _handleContinue,
                ),
                SizedBox(height: 2.h),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildAppBar() {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
      child: Row(
        children: [
          GestureDetector(
            onTap: _handleBackNavigation,
            child: Container(
              padding: EdgeInsets.all(2.w),
              decoration: BoxDecoration(
                color: AppTheme.lightTheme.colorScheme.surface,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: AppTheme.lightTheme.dividerColor,
                  width: 1,
                ),
              ),
              child: CustomIconWidget(
                iconName: 'arrow_back',
                color: AppTheme.lightTheme.colorScheme.onSurface,
                size: 24,
              ),
            ),
          ),
          const Spacer(),
          Text(
            'MotoRide',
            style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
              fontWeight: FontWeight.w700,
              color: AppTheme.lightTheme.colorScheme.primary,
            ),
          ),
          const Spacer(),
          GestureDetector(
            onTap: _handleSettingsNavigation,
            child: Container(
              padding: EdgeInsets.all(2.w),
              decoration: BoxDecoration(
                color: AppTheme.lightTheme.colorScheme.surface,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: AppTheme.lightTheme.dividerColor,
                  width: 1,
                ),
              ),
              child: CustomIconWidget(
                iconName: 'settings',
                color: AppTheme.lightTheme.colorScheme.onSurface,
                size: 24,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 6.w),
      child: Column(
        children: [
          Text(
            '¿Cómo quieres usar MotoRide?',
            style: AppTheme.lightTheme.textTheme.headlineMedium?.copyWith(
              fontWeight: FontWeight.w700,
              color: AppTheme.lightTheme.colorScheme.onSurface,
            ),
            textAlign: TextAlign.center,
          ),
          SizedBox(height: 1.h),
          Text(
            'Selecciona tu rol para comenzar tu experiencia personalizada',
            style: AppTheme.lightTheme.textTheme.bodyLarge?.copyWith(
              color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
              height: 1.4,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _buildRoleCards() {
    return Column(
      children: [
        // Passenger Card
        RoleCardWidget(
          title: _passengerData["title"] as String,
          subtitle: _passengerData["subtitle"] as String,
          description: _passengerData["description"] as String,
          benefits: (_passengerData["benefits"] as List).cast<String>(),
          imageUrl: _passengerData["imageUrl"] as String,
          isSelected: !_isDriverSelected,
          onTap: () => _handleRoleToggle(false),
          primaryColor: AppTheme.lightTheme.colorScheme.primary,
          backgroundColor: AppTheme.lightTheme.colorScheme.surface,
        ),
        SizedBox(height: 2.h),
        // Driver Card
        RoleCardWidget(
          title: _driverData["title"] as String,
          subtitle: _driverData["subtitle"] as String,
          description: _driverData["description"] as String,
          benefits: (_driverData["benefits"] as List).cast<String>(),
          imageUrl: _driverData["imageUrl"] as String,
          isSelected: _isDriverSelected,
          onTap: () => _handleRoleToggle(true),
          primaryColor: AppTheme.lightTheme.colorScheme.secondary,
          backgroundColor: AppTheme.lightTheme.colorScheme.surface,
        ),
      ],
    );
  }

  Widget _buildAdditionalInfo() {
    final currentData = _isDriverSelected ? _driverData : _passengerData;
    final primaryColor = _isDriverSelected
        ? AppTheme.lightTheme.colorScheme.secondary
        : AppTheme.lightTheme.colorScheme.primary;

    return Container(
      margin: EdgeInsets.symmetric(horizontal: 6.w),
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: primaryColor.withValues(alpha: 0.05),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: primaryColor.withValues(alpha: 0.2),
          width: 1,
        ),
      ),
      child: Column(
        children: [
          Row(
            children: [
              CustomIconWidget(
                iconName: _isDriverSelected ? 'trending_up' : 'schedule',
                color: primaryColor,
                size: 24,
              ),
              SizedBox(width: 3.w),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      _isDriverSelected
                          ? 'Potencial de Ganancias'
                          : 'Tiempo de Espera Promedio',
                      style: AppTheme.lightTheme.textTheme.labelLarge?.copyWith(
                        color: AppTheme.lightTheme.colorScheme.onSurface,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    Text(
                      _isDriverSelected
                          ? (currentData["potentialEarnings"] as String)
                          : (currentData["estimatedWaitTime"] as String),
                      style:
                          AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                        color: primaryColor,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          if (_isDriverSelected) ...[
            SizedBox(height: 2.h),
            Container(
              padding: EdgeInsets.all(3.w),
              decoration: BoxDecoration(
                color: AppTheme.lightTheme.colorScheme.surface,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: AppTheme.lightTheme.dividerColor,
                  width: 1,
                ),
              ),
              child: Row(
                children: [
                  CustomIconWidget(
                    iconName: 'info',
                    color: AppTheme.lightTheme.colorScheme.primary,
                    size: 20,
                  ),
                  SizedBox(width: 3.w),
                  Expanded(
                    child: Text(
                      'Necesitarás verificar tu motocicleta, licencia y documentos antes de comenzar.',
                      style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                        color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                        height: 1.3,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }
}
