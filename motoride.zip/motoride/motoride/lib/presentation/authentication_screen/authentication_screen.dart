import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/auth_form_widget.dart';
import './widgets/auth_header_widget.dart';
import './widgets/social_auth_widget.dart';

class AuthenticationScreen extends StatefulWidget {
  const AuthenticationScreen({Key? key}) : super(key: key);

  @override
  State<AuthenticationScreen> createState() => _AuthenticationScreenState();
}

class _AuthenticationScreenState extends State<AuthenticationScreen>
    with TickerProviderStateMixin {
  bool _isLoginMode = true;
  bool _isLoading = false;
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;

  // Mock credentials for testing
  final Map<String, dynamic> mockCredentials = {
    "passenger": {
      "email": "pasajero@motoride.com",
      "password": "Pasajero123!",
      "fullName": "María González López",
      "phone": "+525512345678"
    },
    "driver": {
      "email": "conductor@motoride.com",
      "password": "Conductor123!",
      "fullName": "Carlos Rodríguez Pérez",
      "phone": "+525587654321"
    },
    "admin": {
      "email": "admin@motoride.com",
      "password": "Admin123!",
      "fullName": "Ana Patricia Martínez",
      "phone": "+525555555555"
    }
  };

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 300),
      vsync: this,
    );

    _fadeAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeInOut,
    ));

    _slideAnimation = Tween<Offset>(
      begin: const Offset(0.0, 0.1),
      end: Offset.zero,
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeOutCubic,
    ));

    _animationController.forward();
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  void _onModeChanged(bool isLogin) {
    if (_isLoginMode != isLogin) {
      setState(() {
        _isLoginMode = isLogin;
      });

      _animationController.reset();
      _animationController.forward();

      // Haptic feedback
      HapticFeedback.selectionClick();
    }
  }

  Future<void> _handleAuthentication(
    String email,
    String password, {
    String? fullName,
    String? phoneNumber,
  }) async {
    setState(() {
      _isLoading = true;
    });

    // Simulate network delay
    await Future.delayed(const Duration(seconds: 2));

    try {
      if (_isLoginMode) {
        // Login validation
        bool isValidLogin = false;

        for (var userType in mockCredentials.keys) {
          var credentials = mockCredentials[userType] as Map<String, dynamic>;
          if (credentials['email'] == email &&
              credentials['password'] == password) {
            isValidLogin = true;
            break;
          }
        }

        if (isValidLogin) {
          // Success haptic feedback
          HapticFeedback.lightImpact();

          // Show success message
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('¡Bienvenido de vuelta!'),
              backgroundColor: AppTheme.lightTheme.colorScheme.primary,
              behavior: SnackBarBehavior.floating,
            ),
          );

          // Navigate to role selection
          Navigator.pushReplacementNamed(context, '/role-selection-screen');
        } else {
          _showErrorMessage('Email o contraseña incorrectos');
        }
      } else {
        // Registration validation
        if (fullName != null && phoneNumber != null) {
          // Check if email already exists
          bool emailExists = false;

          for (var userType in mockCredentials.keys) {
            var credentials = mockCredentials[userType] as Map<String, dynamic>;
            if (credentials['email'] == email) {
              emailExists = true;
              break;
            }
          }

          if (emailExists) {
            _showErrorMessage('Este email ya está registrado');
          } else {
            // Success haptic feedback
            HapticFeedback.lightImpact();

            // Show success message
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text('¡Cuenta creada exitosamente!'),
                backgroundColor: AppTheme.lightTheme.colorScheme.primary,
                behavior: SnackBarBehavior.floating,
              ),
            );

            // Navigate to role selection
            Navigator.pushReplacementNamed(context, '/role-selection-screen');
          }
        }
      }
    } catch (e) {
      _showErrorMessage('Error de conexión. Intenta nuevamente.');
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  Future<void> _handleSocialAuth(String provider) async {
    setState(() {
      _isLoading = true;
    });

    // Simulate social authentication
    await Future.delayed(const Duration(seconds: 2));

    try {
      // Success haptic feedback
      HapticFeedback.lightImpact();

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Autenticación con $provider exitosa'),
          backgroundColor: AppTheme.lightTheme.colorScheme.primary,
          behavior: SnackBarBehavior.floating,
        ),
      );

      // Navigate to role selection
      Navigator.pushReplacementNamed(context, '/role-selection-screen');
    } catch (e) {
      _showErrorMessage('Error al autenticar con $provider');
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  void _showErrorMessage(String message) {
    HapticFeedback.heavyImpact();

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            CustomIconWidget(
              iconName: 'error_outline',
              color: Colors.white,
              size: 20,
            ),
            SizedBox(width: 2.w),
            Expanded(
              child: Text(
                message,
                style: TextStyle(color: Colors.white),
              ),
            ),
          ],
        ),
        backgroundColor: AppTheme.lightTheme.colorScheme.error,
        behavior: SnackBarBehavior.floating,
        duration: const Duration(seconds: 4),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.lightTheme.scaffoldBackgroundColor,
      body: SafeArea(
        child: GestureDetector(
          onTap: () => FocusScope.of(context).unfocus(),
          child: SingleChildScrollView(
            physics: const BouncingScrollPhysics(),
            padding: EdgeInsets.symmetric(horizontal: 6.w),
            child: ConstrainedBox(
              constraints: BoxConstraints(
                minHeight: MediaQuery.of(context).size.height -
                    MediaQuery.of(context).padding.top -
                    MediaQuery.of(context).padding.bottom,
              ),
              child: IntrinsicHeight(
                child: Column(
                  children: [
                    SizedBox(height: 4.h),

                    // Header with logo and segmented control
                    AuthHeaderWidget(
                      isLoginMode: _isLoginMode,
                      onModeChanged: _onModeChanged,
                    ),

                    SizedBox(height: 4.h),

                    // Animated form
                    AnimatedBuilder(
                      animation: _animationController,
                      builder: (context, child) {
                        return FadeTransition(
                          opacity: _fadeAnimation,
                          child: SlideTransition(
                            position: _slideAnimation,
                            child: AuthFormWidget(
                              isLoginMode: _isLoginMode,
                              onSubmit: _handleAuthentication,
                              isLoading: _isLoading,
                            ),
                          ),
                        );
                      },
                    ),

                    SizedBox(height: 4.h),

                    // Social authentication
                    SocialAuthWidget(
                      onSocialAuth: _handleSocialAuth,
                      isLoading: _isLoading,
                    ),

                    SizedBox(height: 3.h),

                    // Mock credentials info (for testing)
                    Container(
                      padding: EdgeInsets.all(4.w),
                      decoration: BoxDecoration(
                        color: AppTheme.lightTheme.colorScheme.surface,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(
                          color: AppTheme.lightTheme.dividerColor,
                        ),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              CustomIconWidget(
                                iconName: 'info_outline',
                                color: AppTheme.lightTheme.colorScheme.primary,
                                size: 20,
                              ),
                              SizedBox(width: 2.w),
                              Text(
                                'Credenciales de prueba',
                                style: AppTheme.lightTheme.textTheme.titleSmall
                                    ?.copyWith(
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ],
                          ),
                          SizedBox(height: 2.h),
                          _buildCredentialInfo('Pasajero',
                              'pasajero@motoride.com', 'Pasajero123!'),
                          SizedBox(height: 1.h),
                          _buildCredentialInfo('Conductor',
                              'conductor@motoride.com', 'Conductor123!'),
                          SizedBox(height: 1.h),
                          _buildCredentialInfo(
                              'Admin', 'admin@motoride.com', 'Admin123!'),
                        ],
                      ),
                    ),

                    SizedBox(height: 2.h),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildCredentialInfo(String role, String email, String password) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          role,
          style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
            fontWeight: FontWeight.w600,
            color: AppTheme.lightTheme.colorScheme.primary,
          ),
        ),
        Text(
          'Email: $email',
          style: AppTheme.lightTheme.textTheme.bodySmall,
        ),
        Text(
          'Contraseña: $password',
          style: AppTheme.lightTheme.textTheme.bodySmall,
        ),
      ],
    );
  }
}