import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class AuthFormWidget extends StatefulWidget {
  final bool isLoginMode;
  final Function(String email, String password,
      {String? fullName, String? phoneNumber}) onSubmit;
  final bool isLoading;

  const AuthFormWidget({
    Key? key,
    required this.isLoginMode,
    required this.onSubmit,
    required this.isLoading,
  }) : super(key: key);

  @override
  State<AuthFormWidget> createState() => _AuthFormWidgetState();
}

class _AuthFormWidgetState extends State<AuthFormWidget> {
  final _formKey = GlobalKey<FormState>();
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  final _fullNameController = TextEditingController();
  final _phoneController = TextEditingController();

  bool _obscurePassword = true;
  bool _rememberMe = false;
  bool _acceptTerms = false;
  String _selectedCountryCode = '+52';

  // Password strength indicator
  double _passwordStrength = 0.0;
  String _passwordStrengthText = '';
  Color _passwordStrengthColor = Colors.red;

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    _fullNameController.dispose();
    _phoneController.dispose();
    super.dispose();
  }

  void _calculatePasswordStrength(String password) {
    double strength = 0.0;
    String strengthText = 'Débil';
    Color strengthColor = Colors.red;

    if (password.length >= 8) strength += 0.25;
    if (password.contains(RegExp(r'[A-Z]'))) strength += 0.25;
    if (password.contains(RegExp(r'[0-9]'))) strength += 0.25;
    if (password.contains(RegExp(r'[!@#$%^&*(),.?":{}|<>]'))) strength += 0.25;

    if (strength <= 0.25) {
      strengthText = 'Muy débil';
      strengthColor = Colors.red;
    } else if (strength <= 0.5) {
      strengthText = 'Débil';
      strengthColor = Colors.orange;
    } else if (strength <= 0.75) {
      strengthText = 'Buena';
      strengthColor = Colors.yellow[700]!;
    } else {
      strengthText = 'Fuerte';
      strengthColor = Colors.green;
    }

    setState(() {
      _passwordStrength = strength;
      _passwordStrengthText = strengthText;
      _passwordStrengthColor = strengthColor;
    });
  }

  bool _isFormValid() {
    if (widget.isLoginMode) {
      return _emailController.text.isNotEmpty &&
          _passwordController.text.isNotEmpty;
    } else {
      return _fullNameController.text.isNotEmpty &&
          _emailController.text.isNotEmpty &&
          _phoneController.text.isNotEmpty &&
          _passwordController.text.isNotEmpty &&
          _acceptTerms;
    }
  }

  String? _validateEmail(String? value) {
    if (value == null || value.isEmpty) {
      return 'El email es requerido';
    }
    if (!RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$').hasMatch(value)) {
      return 'Ingresa un email válido';
    }
    return null;
  }

  String? _validatePassword(String? value) {
    if (value == null || value.isEmpty) {
      return 'La contraseña es requerida';
    }
    if (!widget.isLoginMode && value.length < 8) {
      return 'La contraseña debe tener al menos 8 caracteres';
    }
    return null;
  }

  String? _validateFullName(String? value) {
    if (value == null || value.isEmpty) {
      return 'El nombre completo es requerido';
    }
    if (value.trim().split(' ').length < 2) {
      return 'Ingresa tu nombre y apellido';
    }
    return null;
  }

  String? _validatePhone(String? value) {
    if (value == null || value.isEmpty) {
      return 'El teléfono es requerido';
    }
    if (value.length < 10) {
      return 'Ingresa un número válido';
    }
    return null;
  }

  void _showCountryPicker() {
    showModalBottomSheet(
      context: context,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => Container(
        height: 40.h,
        padding: EdgeInsets.all(4.w),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Seleccionar país',
              style: AppTheme.lightTheme.textTheme.titleLarge,
            ),
            SizedBox(height: 2.h),
            Expanded(
              child: ListView(
                children: [
                  _buildCountryOption('🇲🇽', 'México', '+52'),
                  _buildCountryOption('🇺🇸', 'Estados Unidos', '+1'),
                  _buildCountryOption('🇪🇸', 'España', '+34'),
                  _buildCountryOption('🇦🇷', 'Argentina', '+54'),
                  _buildCountryOption('🇨🇴', 'Colombia', '+57'),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCountryOption(String flag, String country, String code) {
    return ListTile(
      leading: Text(flag, style: TextStyle(fontSize: 24)),
      title: Text(country),
      trailing: Text(code, style: AppTheme.lightTheme.textTheme.bodyMedium),
      onTap: () {
        setState(() {
          _selectedCountryCode = code;
        });
        Navigator.pop(context);
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Form(
      key: _formKey,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          if (!widget.isLoginMode) ...[
            TextFormField(
              controller: _fullNameController,
              decoration: InputDecoration(
                labelText: 'Nombre completo',
                hintText: 'Juan Pérez García',
                prefixIcon: Padding(
                  padding: EdgeInsets.all(3.w),
                  child: CustomIconWidget(
                    iconName: 'person',
                    color: AppTheme.lightTheme.colorScheme.primary,
                    size: 20,
                  ),
                ),
              ),
              textInputAction: TextInputAction.next,
              validator: _validateFullName,
              onChanged: (_) => setState(() {}),
            ),
            SizedBox(height: 3.h),
          ],
          TextFormField(
            controller: _emailController,
            decoration: InputDecoration(
              labelText: 'Email',
              hintText: 'ejemplo@correo.com',
              prefixIcon: Padding(
                padding: EdgeInsets.all(3.w),
                child: CustomIconWidget(
                  iconName: 'email',
                  color: AppTheme.lightTheme.colorScheme.primary,
                  size: 20,
                ),
              ),
            ),
            keyboardType: TextInputType.emailAddress,
            textInputAction: TextInputAction.next,
            validator: _validateEmail,
            onChanged: (_) => setState(() {}),
          ),
          if (!widget.isLoginMode) ...[
            SizedBox(height: 3.h),
            Row(
              children: [
                GestureDetector(
                  onTap: _showCountryPicker,
                  child: Container(
                    padding:
                        EdgeInsets.symmetric(horizontal: 4.w, vertical: 4.w),
                    decoration: BoxDecoration(
                      border:
                          Border.all(color: AppTheme.lightTheme.dividerColor),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(_selectedCountryCode,
                            style: AppTheme.lightTheme.textTheme.bodyLarge),
                        SizedBox(width: 1.w),
                        CustomIconWidget(
                          iconName: 'keyboard_arrow_down',
                          color: AppTheme.lightTheme.colorScheme.primary,
                          size: 20,
                        ),
                      ],
                    ),
                  ),
                ),
                SizedBox(width: 3.w),
                Expanded(
                  child: TextFormField(
                    controller: _phoneController,
                    decoration: InputDecoration(
                      labelText: 'Teléfono',
                      hintText: '5512345678',
                      prefixIcon: Padding(
                        padding: EdgeInsets.all(3.w),
                        child: CustomIconWidget(
                          iconName: 'phone',
                          color: AppTheme.lightTheme.colorScheme.primary,
                          size: 20,
                        ),
                      ),
                    ),
                    keyboardType: TextInputType.phone,
                    textInputAction: TextInputAction.next,
                    validator: _validatePhone,
                    onChanged: (_) => setState(() {}),
                  ),
                ),
              ],
            ),
          ],
          SizedBox(height: 3.h),
          TextFormField(
            controller: _passwordController,
            decoration: InputDecoration(
              labelText: 'Contraseña',
              hintText: widget.isLoginMode
                  ? 'Ingresa tu contraseña'
                  : 'Mínimo 8 caracteres',
              prefixIcon: Padding(
                padding: EdgeInsets.all(3.w),
                child: CustomIconWidget(
                  iconName: 'lock',
                  color: AppTheme.lightTheme.colorScheme.primary,
                  size: 20,
                ),
              ),
              suffixIcon: IconButton(
                icon: CustomIconWidget(
                  iconName: _obscurePassword ? 'visibility' : 'visibility_off',
                  color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                  size: 20,
                ),
                onPressed: () =>
                    setState(() => _obscurePassword = !_obscurePassword),
              ),
            ),
            obscureText: _obscurePassword,
            textInputAction: TextInputAction.done,
            validator: _validatePassword,
            onChanged: (value) {
              setState(() {});
              if (!widget.isLoginMode) {
                _calculatePasswordStrength(value);
              }
            },
          ),
          if (!widget.isLoginMode && _passwordController.text.isNotEmpty) ...[
            SizedBox(height: 2.h),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Text('Seguridad: ',
                        style: AppTheme.lightTheme.textTheme.bodySmall),
                    Text(_passwordStrengthText,
                        style:
                            AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                          color: _passwordStrengthColor,
                          fontWeight: FontWeight.w500,
                        )),
                  ],
                ),
                SizedBox(height: 1.h),
                LinearProgressIndicator(
                  value: _passwordStrength,
                  backgroundColor: Colors.grey[300],
                  valueColor:
                      AlwaysStoppedAnimation<Color>(_passwordStrengthColor),
                ),
              ],
            ),
          ],
          if (widget.isLoginMode) ...[
            SizedBox(height: 2.h),
            Row(
              children: [
                Checkbox(
                  value: _rememberMe,
                  onChanged: (value) =>
                      setState(() => _rememberMe = value ?? false),
                ),
                Text('Recordarme',
                    style: AppTheme.lightTheme.textTheme.bodyMedium),
                Spacer(),
                TextButton(
                  onPressed: () {
                    // Navigate to forgot password
                  },
                  child: Text('¿Olvidaste tu contraseña?'),
                ),
              ],
            ),
          ],
          if (!widget.isLoginMode) ...[
            SizedBox(height: 3.h),
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Checkbox(
                  value: _acceptTerms,
                  onChanged: (value) =>
                      setState(() => _acceptTerms = value ?? false),
                ),
                Expanded(
                  child: RichText(
                    text: TextSpan(
                      style: AppTheme.lightTheme.textTheme.bodySmall,
                      children: [
                        TextSpan(text: 'Acepto los '),
                        TextSpan(
                          text: 'Términos y Condiciones',
                          style: TextStyle(
                            color: AppTheme.lightTheme.colorScheme.primary,
                            decoration: TextDecoration.underline,
                          ),
                        ),
                        TextSpan(text: ' y la '),
                        TextSpan(
                          text: 'Política de Privacidad',
                          style: TextStyle(
                            color: AppTheme.lightTheme.colorScheme.primary,
                            decoration: TextDecoration.underline,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ],
          SizedBox(height: 4.h),
          SizedBox(
            height: 7.h,
            child: ElevatedButton(
              onPressed: _isFormValid() && !widget.isLoading
                  ? () {
                      if (_formKey.currentState!.validate()) {
                        widget.onSubmit(
                          _emailController.text.trim(),
                          _passwordController.text,
                          fullName: widget.isLoginMode
                              ? null
                              : _fullNameController.text.trim(),
                          phoneNumber: widget.isLoginMode
                              ? null
                              : '$_selectedCountryCode${_phoneController.text.trim()}',
                        );
                      }
                    }
                  : null,
              child: widget.isLoading
                  ? SizedBox(
                      height: 20,
                      width: 20,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        valueColor: AlwaysStoppedAnimation<Color>(
                          AppTheme.lightTheme.colorScheme.onPrimary,
                        ),
                      ),
                    )
                  : Text(
                      widget.isLoginMode ? 'Iniciar Sesión' : 'Crear Cuenta',
                      style:
                          AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                        color: AppTheme.lightTheme.colorScheme.onPrimary,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
            ),
          ),
        ],
      ),
    );
  }
}
