import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/active_ride_widget.dart';
import './widgets/availability_toggle_widget.dart';
import './widgets/ride_request_modal_widget.dart';
import './widgets/stats_card_widget.dart';

class DriverDashboardScreen extends StatefulWidget {
  const DriverDashboardScreen({Key? key}) : super(key: key);

  @override
  State<DriverDashboardScreen> createState() => _DriverDashboardScreenState();
}

class _DriverDashboardScreenState extends State<DriverDashboardScreen>
    with TickerProviderStateMixin {
  late TabController _tabController;
  bool _isOnline = false;
  bool _showRideRequest = false;
  bool _hasActiveRide = false;
  Map<String, dynamic>? _currentRideRequest;
  Map<String, dynamic>? _activeRide;

  // Mock data for driver stats
  final Map<String, dynamic> _driverStats = {
    'todayEarnings': '\$450.00',
    'completedRides': '12',
    'averageRating': '4.8',
    'onlineHours': '6.5h',
  };

  // Mock data for ride requests
  final List<Map<String, dynamic>> _mockRideRequests = [
    {
      'id': '1',
      'passengerName': 'María González',
      'passengerAvatar':
          'https://images.unsplash.com/photo-1494790108755-2616b612b786?w=150&h=150&fit=crop&crop=face',
      'passengerRating': 4.9,
      'pickupLocation': 'Centro Comercial Plaza Norte, Av. Insurgentes 1234',
      'destination': 'Universidad Nacional, Ciudad Universitaria',
      'fare': '\$85.00',
      'distance': '8.5',
      'estimatedTime': '12',
    },
    {
      'id': '2',
      'passengerName': 'Carlos Mendoza',
      'passengerAvatar':
          'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face',
      'passengerRating': 4.7,
      'pickupLocation': 'Aeropuerto Internacional, Terminal 2',
      'destination': 'Hotel Presidente, Zona Rosa',
      'fare': '\$120.00',
      'distance': '15.2',
      'estimatedTime': '18',
    },
  ];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);

    // Simulate incoming ride request after 3 seconds when online
    Future.delayed(const Duration(seconds: 3), () {
      if (_isOnline && !_hasActiveRide && mounted) {
        _simulateIncomingRideRequest();
      }
    });
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  void _simulateIncomingRideRequest() {
    if (_mockRideRequests.isNotEmpty) {
      setState(() {
        _currentRideRequest = _mockRideRequests.first;
        _showRideRequest = true;
      });
    }
  }

  void _handleAvailabilityToggle(bool isOnline) {
    setState(() {
      _isOnline = isOnline;
    });

    if (isOnline && !_hasActiveRide) {
      // Simulate incoming request after going online
      Future.delayed(const Duration(seconds: 5), () {
        if (_isOnline && !_hasActiveRide && mounted) {
          _simulateIncomingRideRequest();
        }
      });
    }
  }

  void _handleRideRequestResponse(bool accepted) {
    setState(() {
      _showRideRequest = false;
    });

    if (accepted && _currentRideRequest != null) {
      setState(() {
        _hasActiveRide = true;
        _activeRide = {
          ..._currentRideRequest!,
          'status': 'en_route',
        };
      });
    }

    _currentRideRequest = null;
  }

  void _handleActiveRideAction(String action) {
    switch (action) {
      case 'navigate':
        // Open navigation app
        HapticFeedback.lightImpact();
        break;
      case 'arrived':
        setState(() {
          _activeRide = {
            ..._activeRide!,
            'status': 'arrived',
          };
        });
        break;
      case 'start_trip':
        setState(() {
          _activeRide = {
            ..._activeRide!,
            'status': 'in_progress',
          };
        });
        break;
      case 'complete_trip':
        setState(() {
          _hasActiveRide = false;
          _activeRide = null;
        });
        // Simulate next ride request
        if (_isOnline) {
          Future.delayed(const Duration(seconds: 10), () {
            if (_isOnline && !_hasActiveRide && mounted) {
              _simulateIncomingRideRequest();
            }
          });
        }
        break;
      case 'emergency':
        _showEmergencyDialog();
        break;
    }
  }

  void _showEmergencyDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Row(
          children: [
            CustomIconWidget(
              iconName: 'emergency',
              color: AppTheme.lightTheme.colorScheme.error,
              size: 6.w,
            ),
            SizedBox(width: 2.w),
            Text(
              'Emergencia',
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                    color: AppTheme.lightTheme.colorScheme.error,
                    fontWeight: FontWeight.w600,
                  ),
            ),
          ],
        ),
        content: Text(
          '¿Necesitas ayuda de emergencia? Esto alertará a nuestro equipo de soporte y servicios de emergencia.',
          style: Theme.of(context).textTheme.bodyMedium,
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancelar'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              // Handle emergency action
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: AppTheme.lightTheme.colorScheme.error,
            ),
            child: const Text('Llamar Emergencia'),
          ),
        ],
      ),
    );
  }

  Widget _buildDashboardTab() {
    return SingleChildScrollView(
      child: Column(
        children: [
          // Availability toggle
          AvailabilityToggleWidget(
            isOnline: _isOnline,
            onToggle: _handleAvailabilityToggle,
          ),

          // Map placeholder
          Container(
            width: double.infinity,
            height: 30.h,
            margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
            decoration: BoxDecoration(
              color: AppTheme.lightTheme.colorScheme.surface,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(
                color: AppTheme.lightTheme.colorScheme.outline
                    .withValues(alpha: 0.2),
              ),
            ),
            child: Stack(
              children: [
                // Map background
                Container(
                  width: double.infinity,
                  height: double.infinity,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(16),
                    gradient: LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: [
                        AppTheme.lightTheme.colorScheme.primary
                            .withValues(alpha: 0.1),
                        AppTheme.lightTheme.colorScheme.secondary
                            .withValues(alpha: 0.1),
                      ],
                    ),
                  ),
                ),
                // Map overlay
                Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      CustomIconWidget(
                        iconName: 'location_on',
                        color: AppTheme.lightTheme.colorScheme.primary,
                        size: 12.w,
                      ),
                      SizedBox(height: 2.h),
                      Text(
                        _isOnline
                            ? 'Tu ubicación actual'
                            : 'Conéctate para ver el mapa',
                        style: Theme.of(context)
                            .textTheme
                            .titleMedium
                            ?.copyWith(
                              color: AppTheme.lightTheme.colorScheme.onSurface
                                  .withValues(alpha: 0.7),
                              fontWeight: FontWeight.w500,
                            ),
                      ),
                      if (_isOnline) ...[
                        SizedBox(height: 1.h),
                        Text(
                          'Zona Centro - Alta demanda',
                          style: Theme.of(context)
                              .textTheme
                              .bodySmall
                              ?.copyWith(
                                color:
                                    AppTheme.lightTheme.colorScheme.secondary,
                                fontWeight: FontWeight.w500,
                              ),
                        ),
                      ],
                    ],
                  ),
                ),
              ],
            ),
          ),

          // Stats cards
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 4.w),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Estadísticas de Hoy',
                  style: Theme.of(context).textTheme.titleLarge?.copyWith(
                        fontWeight: FontWeight.w600,
                      ),
                ),
                SizedBox(height: 2.h),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    StatsCardWidget(
                      title: 'Ganancias',
                      value: _driverStats['todayEarnings'],
                      iconName: 'attach_money',
                      color: AppTheme.lightTheme.colorScheme.primary,
                      subtitle: 'HOY',
                    ),
                    StatsCardWidget(
                      title: 'Viajes',
                      value: _driverStats['completedRides'],
                      iconName: 'directions_car',
                      color: AppTheme.lightTheme.colorScheme.secondary,
                      subtitle: 'COMPLETADOS',
                    ),
                  ],
                ),
                SizedBox(height: 2.h),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    StatsCardWidget(
                      title: 'Calificación',
                      value: _driverStats['averageRating'],
                      iconName: 'star',
                      color: AppTheme.lightTheme.colorScheme.secondary,
                      subtitle: 'PROMEDIO',
                    ),
                    StatsCardWidget(
                      title: 'Tiempo',
                      value: _driverStats['onlineHours'],
                      iconName: 'access_time',
                      color: AppTheme.lightTheme.colorScheme.primary,
                      subtitle: 'EN LÍNEA',
                    ),
                  ],
                ),
              ],
            ),
          ),

          SizedBox(height: 4.h),
        ],
      ),
    );
  }

  Widget _buildEarningsTab() {
    return SingleChildScrollView(
      padding: EdgeInsets.all(4.w),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Resumen de Ganancias',
            style: Theme.of(context).textTheme.titleLarge?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
          ),
          SizedBox(height: 3.h),

          // Earnings summary card
          Container(
            width: double.infinity,
            padding: EdgeInsets.all(4.w),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  AppTheme.lightTheme.colorScheme.primary,
                  AppTheme.lightTheme.colorScheme.primary
                      .withValues(alpha: 0.8),
                ],
              ),
              borderRadius: BorderRadius.circular(16),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Ganancias de Hoy',
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                        color: Colors.white.withValues(alpha: 0.9),
                      ),
                ),
                SizedBox(height: 1.h),
                Text(
                  '\$450.00',
                  style: Theme.of(context).textTheme.displaySmall?.copyWith(
                        color: Colors.white,
                        fontWeight: FontWeight.w700,
                      ),
                ),
                SizedBox(height: 2.h),
                Row(
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Viajes',
                            style: Theme.of(context)
                                .textTheme
                                .bodySmall
                                ?.copyWith(
                                  color: Colors.white.withValues(alpha: 0.8),
                                ),
                          ),
                          Text(
                            '12',
                            style: Theme.of(context)
                                .textTheme
                                .titleLarge
                                ?.copyWith(
                                  color: Colors.white,
                                  fontWeight: FontWeight.w600,
                                ),
                          ),
                        ],
                      ),
                    ),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Promedio',
                            style: Theme.of(context)
                                .textTheme
                                .bodySmall
                                ?.copyWith(
                                  color: Colors.white.withValues(alpha: 0.8),
                                ),
                          ),
                          Text(
                            '\$37.50',
                            style: Theme.of(context)
                                .textTheme
                                .titleLarge
                                ?.copyWith(
                                  color: Colors.white,
                                  fontWeight: FontWeight.w600,
                                ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),

          SizedBox(height: 3.h),

          Text(
            'Historial Semanal',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
          ),
          SizedBox(height: 2.h),

          // Weekly earnings list
          ...List.generate(7, (index) {
            final days = ['Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb', 'Dom'];
            final earnings = [320, 280, 450, 380, 520, 680, 450];
            final trips = [8, 6, 12, 9, 14, 18, 12];
            final isToday = index == 2; // Wednesday is today

            return Container(
              margin: EdgeInsets.only(bottom: 2.h),
              padding: EdgeInsets.all(4.w),
              decoration: BoxDecoration(
                color: isToday
                    ? AppTheme.lightTheme.colorScheme.primary
                        .withValues(alpha: 0.1)
                    : AppTheme.lightTheme.colorScheme.surface,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: isToday
                      ? AppTheme.lightTheme.colorScheme.primary
                      : AppTheme.lightTheme.colorScheme.outline
                          .withValues(alpha: 0.2),
                ),
              ),
              child: Row(
                children: [
                  Container(
                    width: 12.w,
                    height: 12.w,
                    decoration: BoxDecoration(
                      color: isToday
                          ? AppTheme.lightTheme.colorScheme.primary
                          : AppTheme.lightTheme.colorScheme.outline
                              .withValues(alpha: 0.2),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Center(
                      child: Text(
                        days[index],
                        style: Theme.of(context)
                            .textTheme
                            .labelMedium
                            ?.copyWith(
                              color: isToday
                                  ? Colors.white
                                  : AppTheme.lightTheme.colorScheme.onSurface
                                      .withValues(alpha: 0.7),
                              fontWeight: FontWeight.w600,
                            ),
                      ),
                    ),
                  ),
                  SizedBox(width: 4.w),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          '\$${earnings[index]}.00',
                          style: Theme.of(context)
                              .textTheme
                              .titleMedium
                              ?.copyWith(
                                fontWeight: FontWeight.w600,
                                color: isToday
                                    ? AppTheme.lightTheme.colorScheme.primary
                                    : null,
                              ),
                        ),
                        Text(
                          '${trips[index]} viajes',
                          style: Theme.of(context)
                              .textTheme
                              .bodySmall
                              ?.copyWith(
                                color: AppTheme.lightTheme.colorScheme.onSurface
                                    .withValues(alpha: 0.7),
                              ),
                        ),
                      ],
                    ),
                  ),
                  if (isToday)
                    Container(
                      padding: EdgeInsets.symmetric(
                          horizontal: 2.w, vertical: 0.5.h),
                      decoration: BoxDecoration(
                        color: AppTheme.lightTheme.colorScheme.primary,
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Text(
                        'HOY',
                        style: Theme.of(context).textTheme.labelSmall?.copyWith(
                              color: Colors.white,
                              fontWeight: FontWeight.w600,
                            ),
                      ),
                    ),
                ],
              ),
            );
          }),
        ],
      ),
    );
  }

  Widget _buildProfileTab() {
    return SingleChildScrollView(
      padding: EdgeInsets.all(4.w),
      child: Column(
        children: [
          // Profile header
          Container(
            width: double.infinity,
            padding: EdgeInsets.all(4.w),
            decoration: BoxDecoration(
              color: AppTheme.lightTheme.colorScheme.surface,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(
                color: AppTheme.lightTheme.colorScheme.outline
                    .withValues(alpha: 0.2),
              ),
            ),
            child: Column(
              children: [
                Container(
                  width: 25.w,
                  height: 25.w,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: AppTheme.lightTheme.colorScheme.primary,
                      width: 3,
                    ),
                  ),
                  child: CustomImageWidget(
                    imageUrl:
                        'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face',
                    width: 25.w,
                    height: 25.w,
                    fit: BoxFit.cover,
                  ),
                ),
                SizedBox(height: 2.h),
                Text(
                  'Roberto Martínez',
                  style: Theme.of(context).textTheme.titleLarge?.copyWith(
                        fontWeight: FontWeight.w600,
                      ),
                ),
                SizedBox(height: 0.5.h),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    CustomIconWidget(
                      iconName: 'star',
                      color: AppTheme.lightTheme.colorScheme.secondary,
                      size: 5.w,
                    ),
                    SizedBox(width: 1.w),
                    Text(
                      '4.8',
                      style: Theme.of(context).textTheme.titleMedium?.copyWith(
                            fontWeight: FontWeight.w600,
                          ),
                    ),
                    SizedBox(width: 1.w),
                    Text(
                      '(247 calificaciones)',
                      style: Theme.of(context).textTheme.bodySmall?.copyWith(
                            color: AppTheme.lightTheme.colorScheme.onSurface
                                .withValues(alpha: 0.7),
                          ),
                    ),
                  ],
                ),
              ],
            ),
          ),

          SizedBox(height: 3.h),

          // Profile options
          ...List.generate(6, (index) {
            final options = [
              {
                'title': 'Información Personal',
                'icon': 'person',
                'route': '/profile-info'
              },
              {
                'title': 'Mi Motocicleta',
                'icon': 'motorcycle',
                'route': '/motorcycle-info'
              },
              {
                'title': 'Documentos',
                'icon': 'description',
                'route': '/documents'
              },
              {
                'title': 'Configuración',
                'icon': 'settings',
                'route': '/settings'
              },
              {'title': 'Soporte', 'icon': 'help', 'route': '/support'},
              {'title': 'Cerrar Sesión', 'icon': 'logout', 'route': '/logout'},
            ];

            final option = options[index];
            final isLogout = index == 5;

            return Container(
              margin: EdgeInsets.only(bottom: 2.h),
              decoration: BoxDecoration(
                color: AppTheme.lightTheme.colorScheme.surface,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: AppTheme.lightTheme.colorScheme.outline
                      .withValues(alpha: 0.2),
                ),
              ),
              child: Material(
                color: Colors.transparent,
                child: InkWell(
                  onTap: () {
                    HapticFeedback.lightImpact();
                    if (isLogout) {
                      Navigator.pushNamedAndRemoveUntil(
                        context,
                        '/authentication-screen',
                        (route) => false,
                      );
                    } else {
                      // Navigate to respective screens
                    }
                  },
                  borderRadius: BorderRadius.circular(12),
                  child: Padding(
                    padding: EdgeInsets.all(4.w),
                    child: Row(
                      children: [
                        Container(
                          width: 12.w,
                          height: 12.w,
                          decoration: BoxDecoration(
                            color: isLogout
                                ? AppTheme.lightTheme.colorScheme.error
                                    .withValues(alpha: 0.1)
                                : AppTheme.lightTheme.colorScheme.primary
                                    .withValues(alpha: 0.1),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: CustomIconWidget(
                            iconName: option['icon'] as String,
                            color: isLogout
                                ? AppTheme.lightTheme.colorScheme.error
                                : AppTheme.lightTheme.colorScheme.primary,
                            size: 6.w,
                          ),
                        ),
                        SizedBox(width: 4.w),
                        Expanded(
                          child: Text(
                            option['title'] as String,
                            style: Theme.of(context)
                                .textTheme
                                .titleMedium
                                ?.copyWith(
                                  color: isLogout
                                      ? AppTheme.lightTheme.colorScheme.error
                                      : null,
                                  fontWeight: FontWeight.w500,
                                ),
                          ),
                        ),
                        CustomIconWidget(
                          iconName: 'chevron_right',
                          color: AppTheme.lightTheme.colorScheme.onSurface
                              .withValues(alpha: 0.5),
                          size: 5.w,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            );
          }),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.lightTheme.scaffoldBackgroundColor,
      appBar: AppBar(
        title: Text(
          'MotoRide Driver',
          style: Theme.of(context).textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.w600,
              ),
        ),
        actions: [
          IconButton(
            onPressed: () {
              HapticFeedback.lightImpact();
              // Show notifications
            },
            icon: Stack(
              children: [
                CustomIconWidget(
                  iconName: 'notifications',
                  color: AppTheme.lightTheme.colorScheme.onSurface,
                  size: 6.w,
                ),
                if (_isOnline)
                  Positioned(
                    right: 0,
                    top: 0,
                    child: Container(
                      width: 2.w,
                      height: 2.w,
                      decoration: BoxDecoration(
                        color: AppTheme.lightTheme.colorScheme.secondary,
                        shape: BoxShape.circle,
                      ),
                    ),
                  ),
              ],
            ),
          ),
          SizedBox(width: 2.w),
        ],
        bottom: TabBar(
          controller: _tabController,
          tabs: const [
            Tab(text: 'Dashboard'),
            Tab(text: 'Ganancias'),
            Tab(text: 'Perfil'),
          ],
        ),
      ),
      body: Stack(
        children: [
          TabBarView(
            controller: _tabController,
            children: [
              _buildDashboardTab(),
              _buildEarningsTab(),
              _buildProfileTab(),
            ],
          ),

          // Active ride overlay
          if (_hasActiveRide && _activeRide != null)
            Positioned(
              bottom: 0,
              left: 0,
              right: 0,
              child: ActiveRideWidget(
                activeRide: _activeRide!,
                onAction: _handleActiveRideAction,
              ),
            ),

          // Ride request modal
          if (_showRideRequest && _currentRideRequest != null)
            Positioned.fill(
              child: RideRequestModalWidget(
                rideRequest: _currentRideRequest!,
                onResponse: _handleRideRequestResponse,
              ),
            ),
        ],
      ),
    );
  }
}
